defmodule Clear do
  defstruct []
end
